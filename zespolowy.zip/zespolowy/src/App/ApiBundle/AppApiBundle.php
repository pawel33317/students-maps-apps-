<?php

namespace App\ApiBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AppApiBundle extends Bundle
{
}
