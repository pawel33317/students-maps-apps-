<?php

namespace App\ApiBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use App\ApiBundle\Entity;
use Symfony\Component\HttpFoundation\Response;

class DefaultController extends Controller
{
    public function indexAction()
    {
        return $this->render('AppApiBundle:Default:index.html.twig', array('places' => ''));
    }

    public function getPoisListAction()
    {
    	$em = $this->getDoctrine()->getEntityManager();

    	$places = $em->getRepository('AppApiBundle:Place')->findAll();

    	if (!$places) 
    		throw $this->createNotFoundException('Unable to find any places.');

    	$response = new Response(json_encode($places), 200);
    	$response->headers->set('Content-Type', 'application/json');
    	$response->headers->set('Access-Control-Allow-Origin', '*');

    	return $response;
    }

    public function findAction($latitude, $longitude, $radius, $categories)
    {
    	$d = $this->getDoctrine()->getRepository('AppApiBundle:Place')->createQueryBuilder('l');
    	$query = $d
    	->select('l')
    	->addSelect(
            '( 3959 * acos(cos(radians(' . $latitude . '))' .
                '* cos( radians( l.latitude ) )' .
                '* cos( radians( l.longitude )' .
                '- radians(' . $longitude . ') )' .
                '+ sin( radians(' . $latitude . ') )' .
                '* sin( radians( l.latitude ) ) ) ) as distance'
        )
	->having('distance < :distance')
//	->having('l.categories = "kino"')
	->setParameter('distance', $radius)
    	->setMaxResults(10)
    	->orderBy('distance', 'ASC')->getQuery();

    	$places = $query->getResult(); 

    	if (!$places)
    		throw $this->createNotFoundException('Unable to find any places.');

    	$response = new Response(json_encode($places), 200);
    	$response->headers->set('Content-Type', 'application/json');
    	$response->headers->set('Access-Control-Allow-Origin', '*');

    	return $response;
    }
}
