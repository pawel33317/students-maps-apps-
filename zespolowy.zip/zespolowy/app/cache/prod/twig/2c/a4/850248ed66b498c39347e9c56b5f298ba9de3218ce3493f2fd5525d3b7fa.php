<?php

/* AppApiBundle:Default:index.html.twig */
class __TwigTemplate_2ca4850248ed66b498c39347e9c56b5f298ba9de3218ce3493f2fd5525d3b7fa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "Projekt zespołowy...działa!

";
        // line 3
        echo twig_escape_filter($this->env, (isset($context["places"]) ? $context["places"] : $this->getContext($context, "places")), "html", null, true);
        echo "
";
    }

    public function getTemplateName()
    {
        return "AppApiBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 3,  19 => 1,);
    }
}
